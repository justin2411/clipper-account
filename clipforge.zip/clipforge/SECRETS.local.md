# SECRETS – nur lokal. Diese Datei ist in .gitignore und darf NIE ins (öffentliche) Repo.

## Telegram
TELEGRAM_BOT_TOKEN = 8719099081:AAH_aWWqrwqxChNlaEJFNv9TPrsykCCFMMc
TELEGRAM_CHAT_ID   =            # via https://api.telegram.org/bot<TOKEN>/getUpdates
Bot-Name           =
Hinweis: Token kann jederzeit in @BotFather mit /revoke neu erzeugt werden.

## TikTok-Accounts
Account A – Handle:            E-Mail:            Telefon:            Passwort:
Account B – Handle:            E-Mail:            Telefon:            Passwort:

## Vyro
Login-E-Mail:                  Passwort:
Auszahlung (Stripe/PayPal):

## Blotato
Login:                         Passwort:
BLOTATO_API_KEY =
Account-IDs: A-tiktok =        B-tiktok =

## Supabase
Projekt-URL (SUPABASE_URL) =
SUPABASE_SERVICE_ROLE_KEY  =
DB-Passwort =

## GitHub
GITHUB_REPO  =
GITHUB_TOKEN =                 # fine-grained, Scope: Actions write

## Google
GMAIL_CLIENT_ID     =
GMAIL_CLIENT_SECRET =
GMAIL_REFRESH_TOKEN =          # aus scripts/gmail_auth.py
GOOGLE_API_KEY      =          # Gemini (AI Studio)

## Optional
ANTHROPIC_API_KEY =
Assistent (Name/Kontakt/Telegram-Chat-ID):
