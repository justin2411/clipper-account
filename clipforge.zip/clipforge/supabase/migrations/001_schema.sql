-- ClipForge Schema. Mandantenfähig über workspace_id (für späteren Verkauf / mehrere Nutzer).
create extension if not exists pg_cron;
create extension if not exists pg_net;

create table if not exists workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz default now()
);
insert into workspaces (name) select 'default' where not exists (select 1 from workspaces);

create table if not exists campaigns (
  id text primary key,                 -- z.B. mrbeast-book-challenge
  workspace_id uuid references workspaces(id) default (select id from workspaces limit 1),
  platform text not null,              -- vyro | whop | ...
  name text not null,
  external_url text,
  status text not null default 'draft',   -- draft | joined | active | paused | ended
  rate_per_1k_usd numeric,
  min_views int default 0,
  max_per_post_usd numeric,
  min_seconds int default 0,
  footage jsonb default '{}'::jsonb,   -- {type,url}
  required jsonb default '{}'::jsonb,  -- caption, hashtags, overlay_text, tiktok flags
  forbidden jsonb default '{}'::jsonb,
  accounts text[] default '{A,B}',
  platforms text[] default '{tiktok}',
  created_at timestamptz default now()
);

create table if not exists clips (
  id uuid primary key default gen_random_uuid(),
  campaign_id text references campaigns(id),
  account text not null,
  media_url text not null,
  caption text,
  hook_type text,
  status text not null default 'ready',   -- ready | scheduled | posted | submitted | rejected_precheck | rejected_platform
  note text,
  created_at timestamptz default now()
);

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  clip_id uuid references clips(id),
  platform text not null,                 -- tiktok | instagram | youtube
  blotato_submission_id text,
  post_url text,
  scheduled_at timestamptz,
  posted_at timestamptz,
  submitted_at timestamptz,               -- bei Vyro eingereicht (manuell bestätigt)
  views_24h int, views_72h int, views_7d int,
  status text default 'scheduled',
  rejection_reason text
);

create table if not exists costs (
  id bigserial primary key,
  workspace_id uuid,
  kind text,          -- blotato | llm | other
  amount_usd numeric,
  ref text,
  at timestamptz default now()
);

create table if not exists payouts (
  id bigserial primary key,
  campaign_id text references campaigns(id),
  amount_usd numeric,
  source text,        -- email | manual
  at timestamptz default now()
);

create table if not exists events (
  id bigserial primary key,
  campaign_id text,
  event text,
  at timestamptz default now()
);

create table if not exists account_state (
  account text primary key,
  paused boolean default false,
  reason text,
  updated_at timestamptz default now()
);
insert into account_state(account) values ('A'),('B') on conflict do nothing;

-- Dashboard-Views
create or replace view v_clip_performance as
select c.campaign_id, c.account, c.hook_type, p.platform,
       count(*) as posts, avg(p.views_7d) as avg_views_7d,
       sum(case when p.views_7d >= coalesce(ca.min_views,0) then 1 else 0 end) as qualified
from posts p join clips c on c.id = p.clip_id join campaigns ca on ca.id = c.campaign_id
group by 1,2,3,4;

create or replace view v_profit_weekly as
select date_trunc('week', pay.at) as week,
       sum(pay.amount_usd) as revenue_usd,
       (select coalesce(sum(amount_usd),0) from costs where date_trunc('week', at) = date_trunc('week', pay.at)) as cost_usd
from payouts pay group by 1 order by 1 desc;
