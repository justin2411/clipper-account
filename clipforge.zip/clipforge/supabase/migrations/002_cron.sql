-- Vorher: vault.create_secret('https://<ref>.supabase.co','project_url'); vault.create_secret('<service_key>','service_key');
create or replace function call_fn(name text) returns void language sql as $$
  select net.http_post(
    url := (select decrypted_secret from vault.decrypted_secrets where name='project_url') || '/functions/v1/' || name,
    headers := jsonb_build_object('Content-Type','application/json',
               'Authorization','Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='service_key')),
    body := '{}'::jsonb, timeout_milliseconds := 30000);
$$;
select cron.schedule('scout',     '*/10 * * * *', $$select call_fn('scout')$$);
select cron.schedule('publisher', '*/30 * * * *', $$select call_fn('publisher')$$);
select cron.schedule('tracker',   '0 */6 * * *',  $$select call_fn('tracker')$$);
select cron.schedule('notify',    '0 19 * * *',   $$select call_fn('notify')$$);  -- 21:00 Berlin (Sommer)
