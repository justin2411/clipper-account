// Holt Post-Status/URLs/Views von Blotato, prüft Kill-Switch, räumt Storage auf.
import { db, env, telegram, ok } from "../_shared.ts";

const DROP = Number(env("KILL_VIEWS_DROP_RATIO") || 0.2);
const STOP_WORDS = ["spam", "automation", "bot", "inauthentic"];
const BUCKET = env("SUPABASE_STORAGE_BUCKET") || "clips";

Deno.serve(async () => {
  const H = { "blotato-api-key": env("BLOTATO_API_KEY") };
  const open = await db.get("posts", "status=in.(scheduled,posted)&blotato_submission_id=not.is.null&select=*");
  for (const p of open) {
    const s = await (await fetch(`https://backend.blotato.com/v2/posts/${p.blotato_submission_id}`, { headers: H })).json();
    const patch: Record<string, unknown> = {};
    if (s?.status === "published" && s?.postUrl && !p.post_url) { patch.post_url = s.postUrl; patch.posted_at = new Date().toISOString(); patch.status = "posted"; }
    if (typeof s?.views === "number") {
      const age = p.posted_at ? (Date.now() - new Date(p.posted_at).getTime()) / 36e5 : 0;
      if (age >= 24 && p.views_24h == null) patch.views_24h = s.views;
      if (age >= 72 && p.views_72h == null) patch.views_72h = s.views;
      if (age >= 168 && p.views_7d == null) patch.views_7d = s.views;
    }
    if (s?.status === "failed") { patch.status = "rejected_platform"; patch.rejection_reason = s?.error ?? "failed"; }
    if (Object.keys(patch).length) await db.patch("posts", `id=eq.${p.id}`, patch);
  }
  for (const acc of ["A", "B"]) {
    const rej = await db.get("posts", `status=eq.rejected_platform&select=rejection_reason,clips!inner(account)&clips.account=eq.${acc}`);
    if (rej.some((r: any) => STOP_WORDS.some(w => (r.rejection_reason ?? "").toLowerCase().includes(w)))) {
      await db.patch("account_state", `account=eq.${acc}`, { paused: true, reason: "rejection", updated_at: new Date().toISOString() });
      await telegram(`⛔ Account ${acc} pausiert: Ablehnung mit Spam/Automation-Grund. Bitte prüfen.`); continue;
    }
    const w = await db.get("posts", `select=views_72h,posted_at,clips!inner(account)&clips.account=eq.${acc}&views_72h=not.is.null&order=posted_at.desc&limit=40`);
    if (w.length >= 20) {
      const avg = (xs: any[]) => xs.reduce((a, b) => a + (b.views_72h ?? 0), 0) / xs.length;
      const recent = avg(w.slice(0, 10)), prev = avg(w.slice(10, 20));
      if (prev > 0 && recent < prev * DROP) {
        await db.patch("account_state", `account=eq.${acc}`, { paused: true, reason: "views_drop", updated_at: new Date().toISOString() });
        await telegram(`⚠️ Account ${acc} pausiert: Views-Einbruch (${Math.round(recent)} vs ${Math.round(prev)}).`);
      }
    }
  }
  const done = await db.get("clips", "status=eq.submitted&select=id,media_url");
  for (const c of done) {
    const key = c.media_url.split(`/object/public/${BUCKET}/`)[1];
    if (key) await fetch(`${env("SUPABASE_URL")}/storage/v1/object/${BUCKET}/${key}`, { method: "DELETE", headers: { Authorization: `Bearer ${env("SUPABASE_SERVICE_ROLE_KEY")}` } });
    await db.patch("clips", `id=eq.${c.id}`, { status: "archived" });
  }
  return ok();
});
