// Täglich: alle geposteten, noch nicht eingereichten URLs pro Kampagne per Telegram zum Einreichen.
import { db, telegram, ok } from "../_shared.ts";

Deno.serve(async () => {
  const rows = await db.get("posts", "status=eq.posted&submitted_at=is.null&post_url=not.is.null&select=post_url,clips!inner(campaign_id,campaigns(name,external_url,platform))");
  const byCamp: Record<string, { name: string; url: string; platform: string; links: string[] }> = {};
  for (const r of rows) {
    const c = r.clips.campaigns, id = r.clips.campaign_id;
    (byCamp[id] ??= { name: c.name, url: c.external_url, platform: c.platform, links: [] }).links.push(r.post_url);
  }
  for (const [id, c] of Object.entries(byCamp)) {
    await telegram(`📎 ${c.platform.toUpperCase()} – ${c.name}: ${c.links.length} Posts einreichen\n${c.url}\n\n${c.links.join("\n")}\n\nApp → Kampagne → Add post → URLs einfügen. Danach: scripts/mark_submitted.py ${id}`);
  }
  return ok({ campaigns: Object.keys(byCamp).length });
});
