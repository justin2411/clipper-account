export const env = (k: string) => Deno.env.get(k) ?? "";
const H = { apikey: env("SUPABASE_SERVICE_ROLE_KEY"), Authorization: `Bearer ${env("SUPABASE_SERVICE_ROLE_KEY")}`, "Content-Type": "application/json", Prefer: "return=representation" };
export const db = {
  get: async (t: string, q: string) => (await fetch(`${env("SUPABASE_URL")}/rest/v1/${t}?${q}`, { headers: H })).json(),
  insert: (t: string, b: unknown) => fetch(`${env("SUPABASE_URL")}/rest/v1/${t}`, { method: "POST", headers: H, body: JSON.stringify(b) }),
  patch: (t: string, q: string, b: unknown) => fetch(`${env("SUPABASE_URL")}/rest/v1/${t}?${q}`, { method: "PATCH", headers: H, body: JSON.stringify(b) }),
};
export const telegram = (text: string) =>
  fetch(`https://api.telegram.org/bot${env("TELEGRAM_BOT_TOKEN")}/sendMessage`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: env("TELEGRAM_CHAT_ID"), text, disable_web_page_preview: true }) });
export const ok = (b: unknown = { ok: true }) => new Response(JSON.stringify(b), { headers: { "Content-Type": "application/json" } });
