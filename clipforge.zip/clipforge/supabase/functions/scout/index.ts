// Liest neue Benachrichtigungs-Mails (Gmail), legt Kampagnen-Entwürfe an, meldet per Telegram,
// startet den Clip-Job wenn Footage vorhanden. Plattform-Logik: Absender-Domain → Adapter.
import { db, env, telegram, ok } from "../_shared.ts";

const SENDERS: Record<string, string> = { "vyro.com": "vyro", "whop.com": "whop" };

async function gmailToken() {
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: env("GMAIL_CLIENT_ID"), client_secret: env("GMAIL_CLIENT_SECRET"),
      refresh_token: env("GMAIL_REFRESH_TOKEN"), grant_type: "refresh_token" }) });
  return (await r.json()).access_token;
}

async function newMails(tok: string) {
  const q = encodeURIComponent(`newer_than:1d (${Object.keys(SENDERS).map(d => `from:${d}`).join(" OR ")})`);
  const list = await (await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${q}`, { headers: { Authorization: `Bearer ${tok}` } })).json();
  const out = [];
  for (const m of list.messages ?? []) {
    const full = await (await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=full`, { headers: { Authorization: `Bearer ${tok}` } })).json();
    const h = (n: string) => full.payload.headers.find((x: any) => x.name.toLowerCase() === n)?.value ?? "";
    const part = full.payload.parts?.find((p: any) => p.mimeType === "text/plain") ?? full.payload;
    const body = part.body?.data ? atob(part.body.data.replace(/-/g, "+").replace(/_/g, "/")) : "";
    out.push({ id: m.id, subject: h("subject"), from: h("from"), body });
  }
  return out;
}

async function dispatchClipJob(campaignId: string, account: string) {
  return fetch(`https://api.github.com/repos/${env("GITHUB_REPO")}/actions/workflows/clip.yml/dispatches`, {
    method: "POST", headers: { Authorization: `Bearer ${env("GITHUB_TOKEN")}`, Accept: "application/vnd.github+json" },
    body: JSON.stringify({ ref: "main", inputs: { campaign: campaignId, account } }) });
}

Deno.serve(async () => {
  const tok = await gmailToken();
  for (const m of await newMails(tok)) {
    const platform = Object.entries(SENDERS).find(([d]) => m.from.toLowerCase().includes(d))?.[1];
    if (!platform) continue;
    const seen = await db.get("events", `event=eq.mail:${m.id}&select=id`);
    if (seen.length) continue;
    await db.insert("events", { event: `mail:${m.id}` });
    const t = `${m.subject}\n${m.body}`.toLowerCase();
    const payout = t.match(/\$\s?([\d,]+\.?\d*)/);
    if (/approved|earnings|payout|available/.test(t) && payout) {
      await db.insert("payouts", { amount_usd: Number(payout[1].replace(/,/g, "")), source: "email" });
      continue;
    }
    if (/new campaign|campaign.*(live|dropped|open)/.test(t)) {
      const id = `${platform}-${m.subject.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40)}`;
      const url = m.body.match(/https?:\/\/(?:app\.)?vyro\.com\/campaigns\/[\w-]+/)?.[0] ?? "";
      await db.insert("campaigns", { id, platform, name: m.subject, external_url: url, status: "draft" });
      await telegram(`🆕 ${platform.toUpperCase()}: ${m.subject}\n${url}\n\n1) Join tippen  2) Footage-Link (Drive) setzen: scripts/set_footage.py ${id} <url>`);
    }
  }
  const ready = await db.get("campaigns", `status=eq.joined&footage->>url=neq.&select=id,accounts`);
  for (const c of ready) {
    for (const a of c.accounts ?? ["A", "B"]) await dispatchClipJob(c.id, a);
    await db.patch("campaigns", `id=eq.${c.id}`, { status: "active" });
    await db.insert("events", { campaign_id: c.id, event: "clip_jobs_dispatched" });
  }
  return ok();
});
