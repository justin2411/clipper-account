// Nimmt 'ready'-Clips, verteilt sie auf freie Slots (max N/Tag/Account) und schedult sie bei Blotato,
// zeitversetzt über die Plattformen. TikTok-Pflichtfelder inkl. isBrandedContent aus der Kampagne.
import { db, env, ok } from "../_shared.ts";

const ACCOUNTS: Record<string, { slots: string[]; blotato: Record<string, string> }> = JSON.parse(env("ACCOUNTS_JSON") || "{}");
const MAX_PER_DAY = Number(env("MAX_CLIPS_PER_DAY") || 5);
const GAP_MIN = Number(env("PLATFORM_GAP_MIN") || 30);
const DRAFT = env("BLOTATO_DRAFT") === "true";   // Einlaufphase: true → Sichtprüfung in Blotato

async function blotatoPost(accountId: string, platform: string, mediaUrl: string, caption: string, when: string, tiktok: Record<string, unknown>) {
  const target: Record<string, unknown> = { targetType: platform };
  if (platform === "tiktok") Object.assign(target, { privacyLevel: "PUBLIC_TO_EVERYONE", disabledComments: false, disabledDuet: true, disabledStitch: true,
    isBrandedContent: true, isYourBrand: false, isAiGenerated: false, isDraft: DRAFT, ...tiktok });
  if (platform === "youtube") Object.assign(target, { title: caption.split("\n")[0].slice(0, 95), privacyStatus: "public" });
  if (platform === "instagram") Object.assign(target, { mediaType: "reel" });
  const r = await fetch("https://backend.blotato.com/v2/posts", { method: "POST",
    headers: { "blotato-api-key": env("BLOTATO_API_KEY"), "Content-Type": "application/json" },
    body: JSON.stringify({ post: { accountId, content: { text: caption, mediaUrls: [mediaUrl], platform }, target }, scheduledTime: when }) });
  return r.json();
}

Deno.serve(async () => {
  const today = new Date().toISOString().slice(0, 10);
  const paused = (await db.get("account_state", "paused=eq.true&select=account")).map((x: any) => x.account);
  for (const [acc, cfg] of Object.entries(ACCOUNTS)) {
    if (paused.includes(acc)) continue;
    const scheduledToday = await db.get("clips", `status=in.(scheduled,posted)&account=eq.${acc}&created_at=gte.${today}&select=id`);
    const free = cfg.slots.slice(scheduledToday.length, MAX_PER_DAY);
    if (!free.length) continue;
    const clips = await db.get("clips", `status=eq.ready&account=eq.${acc}&select=*,campaigns(*)&order=created_at.asc&limit=${free.length}`);
    for (let i = 0; i < clips.length; i++) {
      const c = clips[i], camp = c.campaigns, slot = free[i];
      const base = new Date(`${today}T${slot}:00Z`);
      let k = 0;
      for (const platform of camp.platforms ?? ["tiktok"]) {
        const when = new Date(base.getTime() + k++ * GAP_MIN * 60000).toISOString();
        const res = await blotatoPost(cfg.blotato[platform], platform, c.media_url, c.caption, when, camp.required?.tiktok ?? {});
        await db.insert("posts", { clip_id: c.id, platform, blotato_submission_id: res?.postSubmissionId ?? null, scheduled_at: when, status: res?.postSubmissionId ? "scheduled" : "error" });
      }
      await db.patch("clips", `id=eq.${c.id}`, { status: "scheduled" });
    }
  }
  return ok();
});
