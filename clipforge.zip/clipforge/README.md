# ClipForge – automatisiertes Clipping-System (Vyro + TikTok zuerst, plattformoffen)

**Phase 1: nur TikTok, 2 Accounts.** Instagram/YouTube später über `platforms:` in der Kampagne aktivieren.

Pipeline: **Kampagne erkennen → Footage → Clips schneiden → prüfen → posten (Blotato) → tracken → Regeln anwenden**.
Menschliche Schritte (bewusst, wegen Plattformregeln): Kampagne beitreten, Footage bereitstellen (bei Frame.io), Post-Links einreichen.

## Architektur
- `platforms/` – Adapter pro Clipping-Plattform (`vyro.py` fertig, `whop.py` Stub). Neue Plattform = eine Datei.
- `pipeline/` – Python: Download, Schnitt (opensource-clipping), Overlay, Caption, Checks, Upload. Läuft in GitHub Actions.
- `supabase/` – Schema, Cron, Edge Functions (Scout, Publisher, Tracker, Notify). Läuft 24/7 kostenlos.
- `config/` – Alles, was sich ändert (Accounts, Kampagnen-Vorlagen, Regeln). Kein Wert im Code.
- `.github/workflows/` – `clip.yml` (schwerer Job), `keepalive.yml` (Supabase-Pause verhindern).

## Setup (einmalig)
1. Supabase-Projekt anlegen → `supabase/migrations/001_schema.sql` ausführen → Extensions `pg_cron`, `pg_net` aktivieren.
2. Secrets in Supabase Vault + GitHub Secrets (siehe `.env.example`).
3. Edge Functions deployen: `supabase functions deploy scout publisher tracker notify`.
4. Cron-Jobs: `supabase/migrations/002_cron.sql` ausführen (Projekt-URL eintragen).
5. Blotato: Accounts verbinden, API-Key erzeugen (beendet Trial → Starter-Abo), Account-IDs in `config/accounts.yaml`.
6. Telegram-Bot anlegen (@BotFather), Chat-ID eintragen.
7. Gmail-API: OAuth-Client, Refresh-Token einmalig erzeugen (`scripts/gmail_auth.py`).
8. Vyro: Social-Accounts verknüpfen, E-Mail-Benachrichtigungen an.

## Täglicher Ablauf (automatisch)
| Schritt | Wo | Auslöser |
|---|---|---|
| Scout liest Vyro-Mails, legt Kampagne an, Telegram | Edge `scout` | Cron 10 min |
| Du: Join + Footage-Link in Telegram antworten | Mensch | – |
| Clip-Job startet | GitHub Actions `clip.yml` | Edge `scout` via workflow_dispatch |
| Clips → Supabase Storage, Zeilen in `clips` | Pipeline | Job-Ende |
| Publisher schedult Slots bei Blotato | Edge `publisher` | Cron 30 min |
| 21:00 Telegram mit Post-URLs zum Einreichen | Edge `notify` | Cron täglich |
| Tracker zieht Views/Kosten, prüft Kill-Switch | Edge `tracker` | Cron 6 h |

## Neue Plattform anbinden
`platforms/base.py` implementieren: `parse_email()`, `campaign_rules()`, `caption()`, `submission_hint()`. Fertig.
