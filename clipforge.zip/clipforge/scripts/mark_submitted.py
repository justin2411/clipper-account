"""Nach dem Einreichen bei Vyro: python scripts/mark_submitted.py <campaign_id>"""
import sys, os, requests
cid = sys.argv[1]
H = {"apikey": os.environ["SUPABASE_SERVICE_ROLE_KEY"], "Authorization": f"Bearer {os.environ['SUPABASE_SERVICE_ROLE_KEY']}", "Content-Type": "application/json"}
U = os.environ["SUPABASE_URL"]
clips = requests.get(f"{U}/rest/v1/clips?campaign_id=eq.{cid}&status=in.(scheduled,posted)&select=id", headers=H).json()
for c in clips:
    requests.patch(f"{U}/rest/v1/posts?clip_id=eq.{c['id']}&submitted_at=is.null", headers=H, json={"submitted_at": "now()"})
    requests.patch(f"{U}/rest/v1/clips?id=eq.{c['id']}", headers=H, json={"status": "submitted"})
print(f"{len(clips)} clips markiert")
