"""Footage-Link setzen + Kampagne auf 'joined' (ersetzt in V1 den Telegram-Befehl /footage).
python scripts/set_footage.py <campaign_id> <drive_url> [config/campaign_template.yaml]"""
import sys, os, requests, yaml
cid, url = sys.argv[1], sys.argv[2]
H = {"apikey": os.environ["SUPABASE_SERVICE_ROLE_KEY"], "Authorization": f"Bearer {os.environ['SUPABASE_SERVICE_ROLE_KEY']}", "Content-Type": "application/json"}
body = {"footage": {"type": "gdrive", "url": url}, "status": "joined"}
if len(sys.argv) > 3:
    t = yaml.safe_load(open(sys.argv[3]))
    body.update({k: t[k] for k in ("rate_per_1k_usd", "min_views", "max_per_post_usd", "min_seconds", "required", "forbidden", "accounts", "platforms") if k in t})
r = requests.patch(f"{os.environ['SUPABASE_URL']}/rest/v1/campaigns?id=eq.{cid}", headers=H, json=body); r.raise_for_status(); print("ok")
