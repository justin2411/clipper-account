"""Upload nach Supabase Storage (öffentlicher Bucket, Objekte werden vom Tracker nach Einreichung gelöscht)."""
import os, requests
from pathlib import Path

URL, KEY, BUCKET = os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_ROLE_KEY"], os.environ.get("SUPABASE_STORAGE_BUCKET", "clips")


def upload(p: Path) -> str:
    key = f"{p.parent.name}/{p.name}"
    r = requests.post(f"{URL}/storage/v1/object/{BUCKET}/{key}", data=p.read_bytes(),
                      headers={"Authorization": f"Bearer {KEY}", "Content-Type": "video/mp4", "x-upsert": "true"})
    r.raise_for_status()
    return f"{URL}/storage/v1/object/public/{BUCKET}/{key}"
