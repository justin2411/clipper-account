"""Schwerer Job (GitHub Actions): Footage → Clips → Overlay → Checks → Storage → DB.
Aufruf: python -m pipeline.main --campaign <id> --account A
"""
import argparse, json, os, subprocess, sys, yaml
from pathlib import Path
from pipeline import download, overlay, checks, storage, db
from platforms import REGISTRY

ROOT = Path(__file__).resolve().parent.parent
WORK = Path("work"); WORK.mkdir(exist_ok=True)


def load_yaml(p): return yaml.safe_load(Path(p).read_text())


def run_clipper(source: Path, flags: str, out_dir: Path) -> list[Path]:
    """Ruft opensource-clipping (gepinnter Submodule-Commit) auf. Rückgabe: fertige Clips."""
    cmd = f'python {ROOT}/vendor/opensource-clipping/main.py --url "{source}" --source gdrive {flags} --ratio 9:16'
    subprocess.run(cmd, shell=True, check=True, cwd=out_dir)
    manifest = json.loads((out_dir / "outputs" / "render_manifest.json").read_text())
    return [out_dir / "outputs" / c["file"] for c in manifest.get("clips", [])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaign", required=True); ap.add_argument("--account", required=True)
    a = ap.parse_args()

    campaign = db.get_campaign(a.campaign)
    acct = next(x for x in load_yaml(ROOT / "config/accounts.yaml")["accounts"] if x["id"] == a.account)
    platform = REGISTRY[campaign["platform"]]
    rules = platform.rules(campaign)

    src = download.fetch(campaign["footage"], WORK / "src")
    if src is None:
        db.log(a.campaign, "footage_missing"); sys.exit(0)

    raw_clips = run_clipper(src, acct["clipper_flags"], WORK / a.account)
    caption = platform.caption(campaign)
    kept = 0
    for clip in raw_clips:
        final = overlay.apply(clip, campaign["required"]["overlay_text"], WORK / "final")
        ok, reason = checks.validate(final, rules, forbidden=campaign.get("forbidden", {}))
        if not ok:
            db.insert_clip(a.campaign, a.account, str(final), status="rejected_precheck", note=reason); continue
        url = storage.upload(final)
        db.insert_clip(a.campaign, a.account, url, status="ready", caption=caption,
                       hook_type=overlay.hook_type_of(clip))
        kept += 1
    db.log(a.campaign, f"pipeline_done account={a.account} kept={kept}/{len(raw_clips)}")


if __name__ == "__main__":
    main()
