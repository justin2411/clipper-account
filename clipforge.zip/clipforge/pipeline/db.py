"""Minimaler Supabase-REST-Client (kein SDK nötig)."""
import os, requests

URL, KEY = os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_ROLE_KEY"]
H = {"apikey": KEY, "Authorization": f"Bearer {KEY}", "Content-Type": "application/json", "Prefer": "return=representation"}


def _q(table, **params):
    r = requests.get(f"{URL}/rest/v1/{table}", headers=H, params=params); r.raise_for_status(); return r.json()


def get_campaign(cid):
    rows = _q("campaigns", id=f"eq.{cid}", select="*")
    if not rows: raise SystemExit(f"campaign {cid} not found")
    return rows[0]


def insert_clip(campaign_id, account, url, status, caption=None, note=None, hook_type=None):
    body = {"campaign_id": campaign_id, "account": account, "media_url": url, "status": status,
            "caption": caption, "note": note, "hook_type": hook_type}
    requests.post(f"{URL}/rest/v1/clips", headers=H, json=body).raise_for_status()


def log(campaign_id, event):
    requests.post(f"{URL}/rest/v1/events", headers=H, json={"campaign_id": campaign_id, "event": event}).raise_for_status()
