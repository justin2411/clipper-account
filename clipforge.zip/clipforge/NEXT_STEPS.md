# Nächste Schritte (in dieser Reihenfolge)

1. Repo auf GitHub anlegen (public), dieses Gerüst pushen, Submodule pinnen:
   git submodule add https://github.com/NaufalRizqullah/opensource-clipping vendor/opensource-clipping
   cd vendor/opensource-clipping && git checkout <commit> && cd ../.. && git add -A && git commit -m "pin clipper"
2. Supabase: Projekt, 001_schema.sql, Vault-Secrets, 002_cron.sql, Functions deployen, Function-Secrets setzen
   (SUPABASE_*, BLOTATO_API_KEY, TELEGRAM_*, GMAIL_*, GITHUB_TOKEN, GITHUB_REPO, ACCOUNTS_JSON).
3. Storage-Bucket `clips` (public) anlegen.
4. Blotato Starter aktivieren, 2 TikTok-Accounts verbinden, IDs in config/accounts.yaml + ACCOUNTS_JSON.
5. Erste Kampagne: config/campaign_template.yaml ausfüllen → scripts/set_footage.py <id> <drive_url> config/campaign_template.yaml
6. Erster Lauf mit Blotato `isDraft: true` (in publisher/index.ts target ergänzen) → Sichtprüfung → Flag entfernen.
7. Nach der ersten echten Vyro-Mail: Absender/Betreff in platforms/vyro.py und scout/index.ts kalibrieren.

Offen für V2: Telegram-Webhook für /footage und /submitted, Dashboard (Cloudflare Pages), Audio-Peak-Scoring, eigener Clipper.
